Tron Game
Developed by Richie King
Background Music: Ganja - Ooyy

Minimum System Requirements:
OS: Windows Vista, 7, 8/8.1, 10
CPU: 64-bit processor
Memory: 1 GB RAM
Storage: 1GB available space

Setup Instructions
1. Visit https://www.python.org/downloads/ and download the latest version for your system 
2. Run the installer (SysAdmin Permissions Required)

Run Instructions:
1. Run Tron.exe this will open up the launcher window
2. Chose a difficulty by pressing either Easy, Medium or Hard Button
3. Use your keyboard to control the players
4. When the Game Over, press Ok to Play Again or Close both windows to exit

Player Controls:
A and D key is used to control Player 1 (Blue)
Left and Right arrow key is for Player 2 (Red)

FAQ:
Q. When running the program, I get an error.
A. If the error states that 'Must be running Python 3.x', then visit the Python download website, install the latest version and uninstall any old versions on your system

Q. The game is corrupt, what do I do?
A. If you are having any issues with the game, you can download the latest version of the game from "https://github.com/Richie-K1N9/Tron", click the green 'Code' button and then 'Download ZIP'

Q. When I launch the game, nothing happens.
A. There is probably an error in the installation of the game or python. Reinstall both

Q. Windows detects .exe game as a virus
A. The game isnt a virus, if you are unable to run the .exe, you can run the .pyw file